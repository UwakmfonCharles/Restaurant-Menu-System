﻿using Just_Nom.Classes;

public class Program
{
    public static void Main(string[] args)
    {
        ConsoleUI.DisplayMenu();
    }

       
}